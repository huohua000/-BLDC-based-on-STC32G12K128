#include "headfile.h"
#include "common.h"
#include "board.h"
#include "STC32Gxx.h"
void PWM_IO_SET0();
uint16 BLDC_accelerator=3000;
unsigned int step=0;
Speed_Pram speed;
void ESC_init()
{
	pwm_init(PWMA_CH1P_P20, 24000, 0); 
	pwm_init(PWMA_CH2P_P22, 24000, 0); 
	pwm_init(PWMA_CH3P_P24, 24000, 0); 	
	PWM_IO_SET0();
}
void PWM_IO_SET0()
{
	pwm_duty(PWMA_CH1P_P20, 0);//AH
	pwm_duty(PWMA_CH2P_P22, 0);//BH
	pwm_duty(PWMA_CH3P_P24, 0);//CH
	AL_IO=0;
	BL_IO=0;
	CL_IO=0;
	
}
void step_test()
{
    step=0;
    step |= P35;//HALL_C
	  step<<=1;
    step |= P36;//HALL_B
	  step<<=1;
    step |= P37;//HALL_A	
		switch(step)
		{
		case 2:  // 010, P2.0-HALL_A下降沿  PWM3, PWM2_L=1		//顺时针
	LEDA=0;
	LEDB=1;
	LEDC=0;
				break;
		case 6:  // 110, P2.2-HALL_C上升沿  PWM3, PWM1_L=1
	LEDA=1;
	LEDB=1;
	LEDC=0;
				break;
		case 4:  // 100, P2.1-HALL_B下降沿  PWM2, PWM1_L=1
	LEDA=1;
	LEDB=0;
	LEDC=0;
				break;
		case 5:  // 101, P2.0-HALL_A上升沿  PWM2, PWM3_L=1
	LEDA=1;
	LEDB=0;
	LEDC=1;	
				break;
		case 1:  // 001, P2.2-HALL_C下c降沿  PWM1, PWM3_L=1
	LEDA=0;
	LEDB=0;
	LEDC=1;		
				break;
		case 3:  // 011, P2.1-HALL_B上升沿  PWM1, PWM2_L=1
	LEDA=0;
	LEDB=1;
	LEDC=1;		
				break;

		default:
				break;
		}	
}
//-------------------------------------------------------------------------------------------------------------------
//  @brief      ÈíÑÓÊ±
//  @param      void                        
//  @return     void          
//  @since      v1.0
//  Sample usage:
//-------------------------------------------------------------------------------------------------------------------
void delay_500ns(void)
{
	  _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
    _nop_();
}



void StepMotor(int direction) // 换相序列函数
{
//	PWMB_IER   = 0;
//	PWMB_CCER1 = 0;
//	PWMB_CCER2 = 0;
     step=0;
    step |= P35;//HALL_C
	  step<<=1;
    step |= P36;//HALL_B
	  step<<=1;
    step |= P37;//HALL_A
//	step = P2 & 0x07;	//P2.0-HALL_A P2.1-HALL_B P2.2-HALL_C
	if(direction)	//顺时针
	{
		switch(step)
		{
		case 6:  // 010, P2.0-HALL_A下降沿  PWM3, PWM2_L=1		//顺时针
				//PWMA_ENO = 0x00;	PWM1_L=0;	PWM3_L=0;
        //PWM_IO_SET0();
//				pwm_duty(PWMA_CH3P_P24, 0);
				AL_IO=0;pwm_duty(PWMA_CH3P_P24, 0);
		    delay_500ns();
				pwm_duty(PWMA_CH3P_P24, BLDC_accelerator);// 打开C相的高端PWM
				BL_IO=1;// 打开B相的低端
//				PWMB_CCER2 = (0x01+0x00);	//P2.2 0x01:允许输入捕获, +0x00:上升沿, +0x02:下降沿
//				PWMB_IER   = 0x08;			//P2.2 使能中断
				break;
		case 4:  // 110, P2.2-HALL_C上升沿  PWM3, PWM1_L=1
//				PWMA_ENO = 0x10;	PWM2_L=0;	PWM3_L=0;	// 打开C相的高端PWM
//				Delay_500ns();
//				PWM1_L = 1;			// 打开A相的低端
//				PWMB_CCER1 = (0x10+0x20);	//P2.1 0x10:允许输入捕获, +0x00:上升沿, +0x20:下降沿
//				PWMB_IER   = 0x04;			//P2.1 使能中断
				//PWM_IO_SET0();
				pwm_duty(PWMA_CH2P_P22, 0);AL_IO=0;
				delay_500ns();
				pwm_duty(PWMA_CH3P_P24, BLDC_accelerator);
				AL_IO=1;
				break;
		case 5:  // 100, P2.1-HALL_B下降沿  PWM2, PWM1_L=1
//				PWMA_ENO = 0x00;	PWM2_L=0;	PWM3_L=0;
//				Delay_500ns();
//				PWMA_ENO = 0x04;	// 打开B相的高端PWM
//				PWM1_L = 1;			// 打开A相的低端
//				PWMB_CCER1 = (0x01+0x00);	//P2.0 0x01:允许输入捕获, +0x00:上升沿, +0x02:下降沿
//				PWMB_IER   = 0x02;			//P2.0 使能中断
//				PWM_IO_SET0();
				//pwm_duty(PWMA_CH2P_P22, 0);
				CL_IO=0;pwm_duty(PWMA_CH2P_P22, 0);	
				delay_500ns();
				pwm_duty(PWMA_CH2P_P22, BLDC_accelerator);
				AL_IO=1;
				break;
		case 1:  // 101, P2.0-HALL_A上升沿  PWM2, PWM3_L=1
//				PWMA_ENO = 0x04;	PWM1_L=0;	PWM2_L=0;	// 打开B相的高端PWM
//				Delay_500ns();
//				PWM3_L = 1;			// 打开C相的低端
//				PWMB_CCER2 = (0x01+0x02);	//P2.2 0x01:允许输入捕获, +0x00:上升沿, +0x02:下降沿
//				PWMB_IER   = 0x08;			//P2.2 使能中断
//				PWM_IO_SET0();
				pwm_duty(PWMA_CH1P_P20, 0);CL_IO=0;							
				delay_500ns();
				pwm_duty(PWMA_CH2P_P22, BLDC_accelerator);
				CL_IO=1;		
				break;
		case 3:  // 001, P2.2-HALL_C下降沿  PWM1, PWM3_L=1
//				PWMA_ENO = 0x00;	PWM1_L=0;	PWM2_L=0;
//				Delay_500ns();
//				PWMA_ENO = 0x01;	// 打开A相的高端PWM
//				PWM3_L = 1;			// 打开C相的低端
//				PWMB_CCER1 = (0x10+0x00);	//P2.1 0x10:允许输入捕获, +0x00:上升沿, +0x20:下降沿
//				PWMB_IER   = 0x04;			//P2.1 使能中断
//				PWM_IO_SET0();
//				pwm_duty(PWMA_CH1P_P20, 0);
				BL_IO=0;pwm_duty(PWMA_CH1P_P20, 0);				
				delay_500ns();
				pwm_duty(PWMA_CH1P_P20, BLDC_accelerator);
				CL_IO=1;			
				break;
		case 2:  // 011, P2.1-HALL_B上升沿  PWM1, PWM2_L=1
//				PWMA_ENO = 0x01;	PWM1_L=0;	PWM3_L=0;	// 打开A相的高端PWM
//				Delay_500ns();
//				PWM2_L = 1;			// 打开B相的低端
//				PWMB_CCER1 = (0x01+0x02);	//P2.0 0x01:允许输入捕获, +0x00:上升沿, +0x02:下降沿
//				PWMB_IER   = 0x02;			//P2.0 使能中断
//				PWM_IO_SET0();
				pwm_duty(PWMA_CH3P_P24, 0);BL_IO=0;// 打开C相的高端PWM
				delay_500ns();				
				pwm_duty(PWMA_CH1P_P20, BLDC_accelerator);
				BL_IO=1;			
				break;

		default:
				break;
		}
	}

	else	//逆时针
	{
		switch(step)
		{
		case 4:  // 100, P2.0-HALL_A下降沿  PWM1, PWM2_L=1		//逆时针
				pwm_duty(PWMA_CH3P_P24, 0);BL_IO=0;// 打开C相的高端PWM
				delay_500ns();				
				pwm_duty(PWMA_CH1P_P20, BLDC_accelerator);
				BL_IO=1;			
				break;
		case 6:  // 110, P2.1-HALL_B上升沿  PWM1, PWM3_L=1
				BL_IO=0;pwm_duty(PWMA_CH1P_P20, 0);				
				delay_500ns();
				pwm_duty(PWMA_CH1P_P20, BLDC_accelerator);
				CL_IO=1;			
				break;
		case 2:  // 010, P2.2-HALL_C下降沿  PWM2, PWM3_L=1
				pwm_duty(PWMA_CH1P_P20, 0);CL_IO=0;							
				delay_500ns();
				pwm_duty(PWMA_CH2P_P22, BLDC_accelerator);
				CL_IO=1;		
				break;
		case 3:  // 011, P2.0-HALL_A上升沿  PWM2, PWM1_L=1
				CL_IO=0;pwm_duty(PWMA_CH2P_P22, 0);	
				delay_500ns();
				pwm_duty(PWMA_CH2P_P22, BLDC_accelerator);
				AL_IO=1;
				break;
		case 1:  // 001, P2.1-HALL_B下降沿  PWM3, PWM1_L=1
				pwm_duty(PWMA_CH2P_P22, 0);AL_IO=0;
				delay_500ns();
				pwm_duty(PWMA_CH3P_P24, BLDC_accelerator);
				AL_IO=1;
				break;
		case 5:  // 101, P2.2-HALL_C上升沿  PWM3, PWM2_L=1
				AL_IO=0;pwm_duty(PWMA_CH3P_P24, 0);
		    delay_500ns();
				pwm_duty(PWMA_CH3P_P24, BLDC_accelerator);// 打开C相的高端PWM
				BL_IO=1;// 打开B相的低端
//				PWMB_CCER2 = (0x01+0x00);	//P2.2 0x01:允许输入捕获, +0x00:上升沿, +0x02:下降沿
//				PWMB_IER   = 0x08;			//P2.2 使能中断
				break;
	
		default:
				break;
		}
	}
}

void StepMotor_Force(void) // 强制换相（测试用）
{
	switch(114514)
	{
	case 0:  // AB  PWM1, PWM2_L=1
		

				pwm_duty(PWMA_CH3P_P24, 0);// 打开C相的高端PWM
	      delay_us(1);
//				BL_IO=0;
				pwm_duty(PWMA_CH1P_P20, BLDC_accelerator);
				BL_IO=1;		
			break;
	case 1:  // AC  PWM1, PWM3_L=1
//				pwm_duty(PWMA_CH1P_P20, 0);
				BL_IO=0;	
	      delay_us(1);	
				pwm_duty(PWMA_CH1P_P20, BLDC_accelerator);
				CL_IO=1;	
			break;
	case 2:  // BC  PWM2, PWM3_L=1
				pwm_duty(PWMA_CH1P_P20, 0);
//				CL_IO=1;			
	      delay_us(1);
				pwm_duty(PWMA_CH2P_P22, BLDC_accelerator);
				CL_IO=1;	
			break;
	case 3:  // BA  PWM2, PWM1_L=1
				//pwm_duty(PWMA_CH2P_P22, 0);
				CL_IO=0;	
	      delay_us(1);
				pwm_duty(PWMA_CH2P_P22, BLDC_accelerator);
				AL_IO=1;
			break;
	case 4:  // CA  PWM3, PWM1_L=1
				pwm_duty(PWMA_CH2P_P22, 0);
//				AL_IO=0;
	      delay_us(1);
				pwm_duty(PWMA_CH3P_P24, BLDC_accelerator);
				AL_IO=1;
			break;
	case 5:  // CB  PWM3, PWM2_L=1
//				pwm_duty(PWMA_CH3P_P24, 0);
				AL_IO=0;
	      delay_us(1);
				pwm_duty(PWMA_CH3P_P24, BLDC_accelerator);// 打开C相的高端PWM
				BL_IO=1;// 打开B相的低端
			break;

	default:
			break;
	}
}

void Speed_Init()
{
	speed.Kp = 33;
	speed.Ki = 20;
	speed.Kd = 0;
	speed.error = 0;
	speed.last_error = 0;
	speed.pre_error = 0;

	speed.setspeed=5;/////这个数*600/7=转速
	speed.setspeed_basic=0;
	speed.aimspeed=speed.setspeed;
	speed.speed_pwm=300;
	speed.speed_now=0;
	
}

int32 speed_increase_pid(Speed_Pram *p)
{
	float kp,ki,kd;
	int32 increase;
	p->error = p->aimspeed - p->speed_now; 
	kp = p->Kp;
	ki = p->Ki / 10.0f;
	kd = p->Kd / 10.0f;

	increase = kp * (p->error - p->last_error)
			 + ki * p->error
			 + kd * (p->error - 2 * p->last_error + p->pre_error);
	
	p->pre_error = p->last_error;
	p->last_error = p->error;

	return increase;
} 

int clip(int num,int min,int max)
{
	if(num>max)
		return max;
	else if(num<min)
		return min;
	else
		return num;
}
